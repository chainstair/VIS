var searchData=
[
  ['sensornameswrapper',['SensorNamesWrapper',['../classat_1_1fhooe_1_1vis_1_1_sensor_names_wrapper.html#afffc0776196143ea96a63d0297bbb71c',1,'at.fhooe.vis.SensorNamesWrapper.SensorNamesWrapper(String[] _sensorNames)'],['../classat_1_1fhooe_1_1vis_1_1_sensor_names_wrapper.html#a11fd0094234720ff66b23afb5966dd3f',1,'at.fhooe.vis.SensorNamesWrapper.SensorNamesWrapper()']]],
  ['sensorswrapper',['SensorsWrapper',['../classat_1_1fhooe_1_1vis_1_1_sensors_wrapper.html#a6178d765914811b17bbe033df0afda79',1,'at.fhooe.vis.SensorsWrapper.SensorsWrapper()'],['../classat_1_1fhooe_1_1vis_1_1_sensors_wrapper.html#a1db7191fe8457e2483bedc7b2942ac09',1,'at.fhooe.vis.SensorsWrapper.SensorsWrapper(EnvData[] _sensors)']]],
  ['setdate',['setDate',['../classat_1_1fhooe_1_1vis_1_1_env_data.html#a3d0aa8de552ed6387dd4ed2b786e63f3',1,'at::fhooe::vis::EnvData']]],
  ['setsensorname',['setSensorName',['../classat_1_1fhooe_1_1vis_1_1_env_data.html#a49332b9bdd502533d81f147aa2b43198',1,'at::fhooe::vis::EnvData']]],
  ['setvalues',['setValues',['../classat_1_1fhooe_1_1vis_1_1_env_data.html#ae33b03c7ca50e65c2f90b14d5557cc88',1,'at::fhooe::vis::EnvData']]]
];
