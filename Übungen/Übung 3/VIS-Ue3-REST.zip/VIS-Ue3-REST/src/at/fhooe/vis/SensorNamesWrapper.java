package at.fhooe.vis;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * EnvData - class defined for UE03, VIS; MC.
 * Class is being used to save environmental sensor names data in XML format.
 * @author Socovka Roman, Seibezeder Anika
 *
 */
@XmlRootElement(name = "mSensorNames")
@XmlAccessorType(XmlAccessType.FIELD)
public class SensorNamesWrapper {
    @XmlElement(name = "sensorName")
    public String[] mSensorNames;

    /**
     * Constructor for SensorNamesWrapper
     * @param _sensorNames sensornames
     */
    public SensorNamesWrapper(String[] _sensorNames) {
        this.mSensorNames = _sensorNames;
    }

    /**
     * Constructor for SensorNamesWrapper
     */
    public SensorNamesWrapper() {
    }
}