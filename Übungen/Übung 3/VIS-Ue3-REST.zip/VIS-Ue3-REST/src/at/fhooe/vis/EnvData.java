package at.fhooe.vis;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.util.Date;

/**
 * EnvData - class defined for UE03, VIS; MC.
 * Class is being used to save Environmental Sensor Data.
 * @author Socovka Roman, Seibezeder Anika
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class EnvData{
    @XmlElement(name = "name")
    private String mSensorName;
    @XmlElement(name = "date")
    private Date mDate;
    @XmlElement(name = "values")
    private int[] mValues;

    /**
     * Constructor for EnvData
     * @param _sensorName The name of the sensor
     * @param _date The date of the sensor
     * @param _valueCount The counts of values, a sensor has
     */
    public EnvData(String _sensorName, Date _date, int _valueCount) {
        this.mSensorName = _sensorName;
        this.mDate = _date;

        this.mValues = new int[_valueCount];

        for (int i = 0; i < _valueCount; i++) {
            this.mValues[i] = (int) (Math.random() * (500 - 1)) + 1;
        }
    }

    /**
     * Constructor for EnvData
     */
    public EnvData() {

    }

    ///Get the date
    public Date getDate() {
        return mDate;
    }

    ///Set the date
    public void setDate(Date _date) {
        this.mDate = _date;
    }

    /// get the values
    public int[] getValues() {
        return mValues;
    }

    ///set the values
    public void setValues(int[] _values) {
        this.mValues = _values;
    }

    ///get the sensor name
    public String getSensorName() {
        return mSensorName;
    }

    ///set the sensor name
    public void setSensorName(String _sensorName) {
        this.mSensorName = _sensorName;
    }

    ///returns a well-written String of the EnvData Class, including sensor name, time and values.
    @Override
    public String toString() {
        String toPrint = "";
        toPrint+= ("Sensor: "+ mSensorName + "\n");
        toPrint+= "Time: " + mDate.toString()+ "\n";
        toPrint+= "Values: ";

        for (int i = 0; i < mValues.length; i++) {
            toPrint+= mValues[i];

            if (i < mValues.length - 1) {
                toPrint += ",";
            }
        }

        toPrint+="\n";

        return toPrint;
    }
}