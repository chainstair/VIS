//
// Created by David on 08.01.2018.
//

#include "LightSensor.h"

LightSensor::LightSensor() {
    mLight = rand();
}

LightSensor::~LightSensor() {

}

string LightSensor::toString() {
    return to_string(mLight);
}

string LightSensor::getName() {
    return "light";
}
