//
// Created by David on 08.01.2018.
//

#include "NoiseSensor.h"

NoiseSensor::NoiseSensor() {
    mNoise = rand();
}

NoiseSensor::~NoiseSensor() {

}

string NoiseSensor::toString() {
    return to_string(mNoise);
}

string NoiseSensor::getName() {
    return "noise";
}
