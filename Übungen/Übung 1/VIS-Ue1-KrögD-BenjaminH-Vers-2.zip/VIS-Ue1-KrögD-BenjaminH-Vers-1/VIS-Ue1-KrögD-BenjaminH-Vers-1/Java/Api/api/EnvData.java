package at.fhooe.mc.api;

public interface EnvData {
	public abstract String toString();
}
