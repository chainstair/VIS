package at.fhooe.mc.interfaces;

/**
 * 
 * @author David
 *
 */
public interface EnvData{
	public abstract long  getTimestamp();
	public abstract int getValue();
	public abstract String getType();
	public abstract String toString();
}


